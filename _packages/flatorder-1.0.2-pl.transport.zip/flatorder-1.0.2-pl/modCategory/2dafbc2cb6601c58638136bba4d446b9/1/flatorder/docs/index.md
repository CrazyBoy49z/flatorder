# FlatOrder

A MODX extra to add a Resources Based "Shopping Cart" Table and/or Product Grid to your site.

After Install visit: https://github.com/dubrod/flatorder
